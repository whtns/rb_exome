# add a title and description line to the beginning of each csv in the supplemental data

library(fs)
library(tidyverse)

table_description <- read_tsv("doc/RB_exome_manuscript/stachelek_supplemental/table_description.txt")

# read in each table 
stachelek_supp_tables <- fs::path(proj_dir, "doc/RB_exome_manuscript/stachelek_supplemental/") %>% 
  dir_ls(regex = ".*[0-9]+.*.csv") %>% 
  purrr::set_names(fs::path_file(.)) %>% 
  purrr::map(read_csv) %>% 
  identity()

append_desc_to_table <- function(supp_table, table_file_name, table_description){
  # browser()
  matching_table <- dplyr::filter(table_description, table_file_name == {{table_file_name}})
  
  title_desc <- paste(matching_table[1,3:4], collapse = ": ")
  legend <- matching_table[[1,5]]
  
  format_table_path <- fs::path("doc/RB_exome_manuscript/stachelek_supplemental", "formatted_tables")
  dir_create(format_table_path)
  
  newpath <- fs::path(format_table_path, table_file_name)
  # tmp <- "~/rb_pipeline/doc/RB_exome_manuscript/stachelek_supplemental/tmp.txt"
  cat(title_desc, "\n", legend, "\n", "\n", file = newpath)
  write_csv(supp_table, path = newpath, append = TRUE, col_names = TRUE)
}


# append_desc_to_table(stachelek_supp_tables[[1]], names(stachelek_supp_tables)[[1]], table_description)


purrr::imap(stachelek_supp_tables, purrr::safely(append_desc_to_table), table_description)

